#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>

#include "string_utils.h"
#include "lmc.h"

int main (int argc, char* argv[]) {
    char* str;

    lmc_state state = {
        .mem = {0},
        .program_counter = 0,
        .accumulator = 0
    };

    if (argc < 2) {
        printf("Please provide a filename containing LMC assembly.");
    }
    else {
        printf("\nreading filename %s", argv[1]);
        char* file = file_into_str(argv[1]);
        size_t index = 0;
        char** file_lines = split_on_delim(file, &index, "\n");
        printf("\n%zu", index);
        /* whi le (true) {
            state.program_counter++;
            Instruction i = parse_input(str);
            if (i.op >= 9 || i.op < 0) {
                printf("incorrect opcode.");
            }
            else {
                if(i.op == 9) {
                    printf("HLT");
                    break;
                }
                else {

                }
            }
        } */
    }
    return 0;
}
