struct StrInfo {
    size_t len;
    size_t old_len;
    char* ptr;
};
#undef String
typedef struct StrInfo String;
#undef READ_CHUNK_SIZE
#define READ_CHUNK_SIZE 32

String lazy_append_to_string(char* dest, const char* input);
String append_to_string(char* dest, const char* input, size_t dest_size, size_t input_len);
char* read_string(char stop_char);
char** split_on_delim(char* str, size_t* index, const char* DELIM);
char* tokenize_string(char* str, const char* delim, size_t* index);
int str_array_contains(const char* arr[], size_t arr_len, char* str);
int str_array_fuzzy_contains(const char* arr[], size_t arr_len, char* str);
char* file_into_str(const char* filename);